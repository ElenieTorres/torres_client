<template>
  <NuxtLayout name="default">
    <NuxtPage/>
  </NuxtLayout>
</template>
