<template>
    <div>
        <h1>Start Your Own Story</h1>
    </div>
</template>