<template> 
    <div>
        <h1>Find New Stories</h1>
        <Booklist/>
    </div>
</template>
