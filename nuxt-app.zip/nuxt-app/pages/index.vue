<template>
    <div>
        <h1>Home</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem ullam nulla recusandae quasi animi. Nesciunt
            nobis voluptatum error possimus sit a animi dolore, illo rem non culpa perferendis impedit quia?</p>
    </div>
</template>
