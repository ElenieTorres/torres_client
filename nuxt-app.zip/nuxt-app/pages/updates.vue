<template>
    <div>
        <h1>Recently Updated Stories</h1>
        <Booklist/>
    </div>
</template>