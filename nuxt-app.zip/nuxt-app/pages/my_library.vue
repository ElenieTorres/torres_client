<template>
    <div>
        <h1>Reading List</h1>
        <Booklist />
    </div>
</template>