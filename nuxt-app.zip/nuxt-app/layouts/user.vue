<template>
    <div>
        <h1>User Layout</h1>
    </div>
</template>